import React, { useState, useEffect, useRef } from 'react';
import { AppTheme, ChannelType, UserProfile, ViewState, Message } from './types';
import MicBoost from './components/MicBoost';
import WindowsTogether from './components/WindowsTogether';
import YouTubeTogether from './components/YouTubeTogether';
import { sendMessageToGemini } from './services/geminiService';
import { io, Socket } from 'socket.io-client';

const App: React.FC = () => {
  const [view, setView] = useState<ViewState>(ViewState.LOGIN);
  const [user, setUser] = useState<UserProfile>({
    username: 'Guest',
    discriminator: '0000',
    avatar: 'https://picsum.photos/50/50',
    micGain: 1.0,
    theme: AppTheme.AMERICAN
  });
  
  // Socket State
  const [socket, setSocket] = useState<Socket | null>(null);
  const [onlineUsers, setOnlineUsers] = useState<any[]>([]);
  const [connectionStatus, setConnectionStatus] = useState('Disconnected');

  const [activeChannel, setActiveChannel] = useState<ChannelType>(ChannelType.TEXT);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  
  // Gemini Chat History (Local only for now, could sync but let's keep it private)
  const [aiHistory, setAiHistory] = useState<{ role: string; parts: { text: string }[] }[]>([]);

  // Refs for scrolling
  const chatBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, activeChannel]);

  // Login Handler
  const handleLogin = (username: string, theme: AppTheme) => {
    const newUser = { 
        ...user, 
        username: username || 'Anon', 
        discriminator: Math.floor(Math.random() * 9000 + 1000).toString(),
        theme
    };
    setUser(newUser);
    setView(ViewState.APP);

    // Initialize Socket
    const newSocket = io(); // Connects to same host/port by default
    
    newSocket.on('connect', () => {
        setConnectionStatus('Connected');
        console.log('Connected to server');
        // Join with user data
        newSocket.emit('join', newUser);
    });

    newSocket.on('disconnect', () => setConnectionStatus('Disconnected'));

    newSocket.on('message', (msg: Message) => {
        setMessages(prev => [...prev, msg]);
    });

    newSocket.on('user_list', (users: any[]) => {
        setOnlineUsers(users);
    });

    setSocket(newSocket);
  };

  // Sync mic gain
  useEffect(() => {
    if (socket && user.micGain) {
        socket.emit('mic_gain', user.micGain);
    }
  }, [user.micGain, socket]);

  // Message Handler
  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      user: user.username,
      avatar: user.avatar,
      content: inputText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      role: 'user'
    };

    if (activeChannel === ChannelType.AI) {
      // Local AI Chat
      setMessages(prev => [...prev, newMessage]);
      setInputText('');
      setIsTyping(true);
      
      const newHistory = [...aiHistory, { role: 'user', parts: [{ text: newMessage.content }] }];
      setAiHistory(newHistory);
      
      const response = await sendMessageToGemini(newMessage.content, newHistory, user.theme);
      
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        user: 'Rucord AI',
        avatar: 'https://picsum.photos/40/40?ai',
        content: response,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        role: 'model'
      };
      
      setMessages(prev => [...prev, botMessage]);
      setAiHistory(prev => [...prev, { role: 'model', parts: [{ text: response }] }]);
      setIsTyping(false);
    } else {
        // Broadcast via Socket
        if (socket) {
            socket.emit('message', newMessage);
            setInputText('');
        }
    }
  };

  // Render Login Screen
  if (view === ViewState.LOGIN) {
    return (
      <div className="min-h-screen bg-[url('https://picsum.photos/1920/1080?blur=5')] bg-cover flex items-center justify-center">
        <div className="bg-[#313338] p-8 rounded-lg shadow-2xl w-96 transform hover:scale-105 transition-transform duration-300">
          <div className="text-center mb-6">
            <h1 className="text-4xl font-black text-white mb-2 tracking-tighter">Rucord</h1>
            <p className="text-gray-400 text-sm">The only place where 1500% volume is standard.</p>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Username</label>
              <input 
                id="usernameInput"
                type="text" 
                className="w-full bg-[#1e1f22] text-white p-2 rounded outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="xX_Destroyer_Xx"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Select Theme</label>
              <select id="themeInput" className="w-full bg-[#1e1f22] text-white p-2 rounded outline-none border-none">
                <option value={AppTheme.AMERICAN}>🇺🇸 American Freedom</option>
                <option value={AppTheme.RUSSIAN}>🇷🇺 Hardbass</option>
                <option value={AppTheme.UKRAINIAN}>🇺🇦 Glory</option>
              </select>
            </div>

            <button 
              onClick={() => {
                const name = (document.getElementById('usernameInput') as HTMLInputElement).value;
                const theme = (document.getElementById('themeInput') as HTMLSelectElement).value as AppTheme;
                handleLogin(name, theme);
              }}
              className="w-full bg-indigo-500 hover:bg-indigo-600 text-white font-bold py-3 rounded transition-colors"
            >
              Enter Rucord
            </button>
            <p className="text-[10px] text-gray-500 text-center mt-2">
              Note: This will connect to the backend server. If using Replit, ensure you hit "Run".
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Theme Config
  const getThemeColors = () => {
    switch(user.theme) {
      case AppTheme.RUSSIAN: return { accent: 'text-red-500', btn: 'bg-red-600 hover:bg-red-700', border: 'border-red-600' };
      case AppTheme.UKRAINIAN: return { accent: 'text-yellow-400', btn: 'bg-blue-600 hover:bg-blue-700', border: 'border-yellow-400' };
      default: return { accent: 'text-indigo-400', btn: 'bg-indigo-500 hover:bg-indigo-600', border: 'border-indigo-500' };
    }
  };
  const themeColors = getThemeColors();

  // Main App UI
  return (
    <div className="flex h-screen bg-[#313338] overflow-hidden">
      {/* Server Sidebar */}
      <div className="w-[72px] bg-[#1e1f22] flex flex-col items-center py-3 gap-2 overflow-y-scroll hidden sm:flex">
        <div className={`w-12 h-12 bg-[#313338] rounded-2xl flex items-center justify-center text-white hover:bg-indigo-500 transition-all cursor-pointer group`}>
            <i className="fa-brands fa-discord text-xl group-hover:text-white"></i>
        </div>
        <div className="w-8 h-[2px] bg-[#35373c] rounded-lg"></div>
        {/* Parody Servers */}
        {[1, 2, 3].map((i) => (
           <div key={i} className="w-12 h-12 rounded-3xl hover:rounded-xl transition-all duration-200 cursor-pointer overflow-hidden relative group">
              <img src={`https://picsum.photos/100/100?random=${i}`} className="w-full h-full object-cover" />
              <div className="absolute left-0 w-1 h-0 bg-white group-hover:h-5 top-1/2 -translate-y-1/2 transition-all rounded-r"></div>
           </div>
        ))}
         <div className="w-12 h-12 bg-[#313338] rounded-3xl hover:rounded-xl hover:bg-green-600 text-green-500 hover:text-white transition-all flex items-center justify-center cursor-pointer">
           <i className="fa-solid fa-plus text-xl"></i>
         </div>
      </div>

      {/* Channel Sidebar */}
      <div className="w-60 bg-[#2b2d31] flex flex-col hidden md:flex">
        <div className="h-12 border-b border-[#1f2023] flex items-center px-4 font-bold shadow-sm hover:bg-[#35373c] cursor-pointer transition-colors">
          Rucord Central
          {user.theme === AppTheme.RUSSIAN && ' 🇷🇺'}
          {user.theme === AppTheme.UKRAINIAN && ' 🇺🇦'}
          {user.theme === AppTheme.AMERICAN && ' 🇺🇸'}
        </div>
        
        <div className="flex-1 overflow-y-auto p-2">
            {/* Status Indicator */}
            <div className={`px-2 py-1 mb-2 text-xs font-mono text-center rounded ${connectionStatus === 'Connected' ? 'bg-green-900 text-green-300' : 'bg-red-900 text-red-300'}`}>
                Status: {connectionStatus}
            </div>

            {/* Category */}
            <div className="pt-4">
                <div className="flex items-center justify-between px-2 text-xs font-bold text-gray-400 uppercase hover:text-gray-300 cursor-pointer mb-1">
                    <span><i className="fa-solid fa-angle-down text-[10px] mr-1"></i> Hangout</span>
                </div>
                <div 
                    onClick={() => setActiveChannel(ChannelType.TEXT)}
                    className={`px-2 py-1.5 rounded flex items-center gap-2 cursor-pointer text-gray-400 hover:text-gray-100 hover:bg-[#35373c] ${activeChannel === ChannelType.TEXT ? 'bg-[#35373c] text-white' : ''}`}
                >
                    <i className="fa-solid fa-hashtag text-gray-500"></i> general-chat
                </div>
                 <div 
                    onClick={() => setActiveChannel(ChannelType.AI)}
                    className={`px-2 py-1.5 rounded flex items-center gap-2 cursor-pointer text-gray-400 hover:text-gray-100 hover:bg-[#35373c] ${activeChannel === ChannelType.AI ? 'bg-[#35373c] text-white' : ''}`}
                >
                    <i className="fa-solid fa-robot text-purple-400"></i> ai-together
                </div>
            </div>

            {/* Category */}
            <div className="pt-4">
                <div className="flex items-center justify-between px-2 text-xs font-bold text-gray-400 uppercase hover:text-gray-300 cursor-pointer mb-1">
                    <span><i className="fa-solid fa-angle-down text-[10px] mr-1"></i> Activities</span>
                </div>
                 <div 
                    onClick={() => setActiveChannel(ChannelType.WINDOWS)}
                    className={`px-2 py-1.5 rounded flex items-center gap-2 cursor-pointer text-gray-400 hover:text-gray-100 hover:bg-[#35373c] ${activeChannel === ChannelType.WINDOWS ? 'bg-[#35373c] text-white' : ''}`}
                >
                    <i className="fa-brands fa-windows text-blue-400"></i> windows-together
                </div>
                 <div 
                    onClick={() => setActiveChannel(ChannelType.YOUTUBE)}
                    className={`px-2 py-1.5 rounded flex items-center gap-2 cursor-pointer text-gray-400 hover:text-gray-100 hover:bg-[#35373c] ${activeChannel === ChannelType.YOUTUBE ? 'bg-[#35373c] text-white' : ''}`}
                >
                    <i className="fa-brands fa-youtube text-red-500"></i> youtube-together
                </div>
            </div>
        </div>

        {/* User Area */}
        <div className="bg-[#232428] p-2 flex flex-col">
            <div className="flex items-center justify-between mb-2">
                 <div className="flex items-center gap-2">
                    <div className="relative">
                        <img src={user.avatar} className="w-8 h-8 rounded-full bg-gray-500" />
                        <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-[#232428]"></div>
                    </div>
                    <div className="text-sm">
                        <div className="font-bold leading-tight">{user.username}</div>
                        <div className="text-xs text-gray-400">#{user.discriminator}</div>
                    </div>
                </div>
            </div>
           
           {/* Mic Boost Control */}
           <MicBoost gainValue={user.micGain} setGainValue={(val) => setUser({...user, micGain: val})} />
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 bg-[#313338]">
        {/* Header */}
        <div className="h-12 border-b border-[#26272d] flex items-center px-4 shadow-sm">
            <div className="flex items-center gap-2 text-gray-200 font-bold text-md">
                <i className="fa-solid fa-hashtag text-gray-400 text-xl"></i>
                {activeChannel === ChannelType.GUIDE ? 'how-to-replit' : 
                 activeChannel === ChannelType.AI ? 'ai-together' : 
                 activeChannel === ChannelType.WINDOWS ? 'windows-together' :
                 activeChannel === ChannelType.YOUTUBE ? 'youtube-together' : 'general-chat'}
            </div>
             {activeChannel === ChannelType.AI && (
                 <span className="ml-2 text-xs bg-purple-600 text-white px-1 rounded">BOT</span>
             )}
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto flex flex-col relative">
            
            {activeChannel === ChannelType.WINDOWS && (
                <WindowsTogether socket={socket} />
            )}

            {activeChannel === ChannelType.YOUTUBE && (
                <YouTubeTogether socket={socket} />
            )}

            {activeChannel === ChannelType.GUIDE && (
                <div className="p-8 max-w-3xl">
                    <h1 className="text-3xl font-bold mb-4 text-white">How to Replit it</h1>
                    <p className="mb-4">1. Press the Run button.</p>
                    <p className="mb-4">2. The server (`server.js`) starts on port 3000.</p>
                    <p className="mb-4">3. Share the web URL with friends.</p>
                </div>
            )}

            {(activeChannel === ChannelType.TEXT || activeChannel === ChannelType.AI) && (
                <div className="flex-1 p-4 space-y-4">
                    {/* Welcome Message */}
                     <div className="mt-4 mb-8">
                        <div className="w-16 h-16 bg-gray-600 rounded-full flex items-center justify-center mb-4">
                             <i className="fa-solid fa-hashtag text-3xl text-white"></i>
                        </div>
                        <h1 className="text-3xl font-bold text-white mb-2">Welcome to #{activeChannel === ChannelType.AI ? 'ai-together' : 'general-chat'}!</h1>
                        <p className="text-gray-400">You are connected with {onlineUsers.length} users.</p>
                     </div>

                    {messages.map((msg) => (
                        <div key={msg.id} className={`flex gap-4 group hover:bg-[#2e3035] -mx-4 px-4 py-1 mt-[17px] ${msg.role === 'model' ? 'bg-[#2e3035]/50 border-l-2 border-purple-500' : ''}`}>
                            <div className="flex-none mt-0.5 cursor-pointer">
                                <img src={msg.avatar} alt="avatar" className="w-10 h-10 rounded-full hover:opacity-80 transition-opacity" />
                            </div>
                            <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2">
                                    <span className={`font-bold hover:underline cursor-pointer ${msg.role === 'model' ? 'text-purple-400' : 'text-white'}`}>
                                        {msg.user}
                                        {msg.role === 'model' && <span className="ml-1 text-[10px] bg-purple-600 text-white px-1 rounded uppercase align-middle">Bot</span>}
                                    </span>
                                    <span className="text-xs text-gray-400">{msg.timestamp}</span>
                                </div>
                                <p className={`text-gray-100 whitespace-pre-wrap ${user.theme === AppTheme.RUSSIAN && msg.role === 'model' ? 'font-mono' : ''}`}>
                                    {msg.content}
                                </p>
                            </div>
                        </div>
                    ))}
                    {isTyping && activeChannel === ChannelType.AI && (
                         <div className="flex gap-4 px-4 py-1">
                            <div className="w-10 h-10"></div>
                            <div className="text-sm text-gray-400 animate-pulse">Rucord AI is thinking...</div>
                        </div>
                    )}
                    <div ref={chatBottomRef} />
                </div>
            )}
        </div>

        {/* Input Area */}
        {(activeChannel === ChannelType.TEXT || activeChannel === ChannelType.AI) && (
             <div className="p-4 pt-0">
                <div className="bg-[#383a40] rounded-lg px-4 py-2.5 flex items-center gap-3">
                    <button className="text-gray-400 hover:text-gray-200 transition-colors">
                        <i className="fa-solid fa-circle-plus text-xl"></i>
                    </button>
                    <input 
                        type="text" 
                        value={inputText}
                        onChange={(e) => setInputText(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                        className="flex-1 bg-transparent border-none outline-none text-gray-200 placeholder-gray-400"
                        placeholder={`Message #${activeChannel === ChannelType.AI ? 'ai-together' : 'general-chat'}`}
                    />
                </div>
                {activeChannel === ChannelType.AI && (
                    <div className="text-[10px] text-gray-500 mt-1 text-right">
                        AI Model: Gemini 2.5 Flash
                    </div>
                )}
            </div>
        )}
      </div>

      {/* User List Sidebar (Right) */}
      <div className="w-60 bg-[#2b2d31] hidden lg:flex flex-col p-4 overflow-y-auto">
        <h3 className="text-xs font-bold text-gray-400 uppercase mb-4">Online — {onlineUsers.length}</h3>
        
        {onlineUsers.map((u) => (
             <div key={u.id} className="flex items-center gap-3 mb-4 opacity-100 hover:bg-[#35373c] p-1 rounded cursor-pointer">
                <div className="relative">
                    <img src={u.avatar} className="w-8 h-8 rounded-full" />
                    <div className={`absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-[#2b2d31] ${u.micGain > 10 ? 'animate-ping bg-red-500' : ''}`}></div>
                </div>
                <div>
                    <div className={`font-bold text-sm text-white`}>{u.username}</div>
                    <div className={`text-xs ${u.micGain > 5 ? 'text-red-400 font-bold' : 'text-gray-400'}`}>
                        {u.micGain > 10 ? 'EAR RAPE' : u.micGain > 5 ? 'SCREAMING' : 'Chilling'}
                    </div>
                </div>
            </div>
        ))}
      </div>
    </div>
  );
};

export default App;