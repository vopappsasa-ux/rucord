import React, { useState, useEffect } from 'react';

interface YouTubeTogetherProps {
  socket: any;
}

const YouTubeTogether: React.FC<YouTubeTogetherProps> = ({ socket }) => {
    const [videoUrl, setVideoUrl] = useState("https://www.youtube.com/watch?v=dQw4w9WgXcQ");
    const [isPlaying, setIsPlaying] = useState(false);
    
    // Listen for server updates
    useEffect(() => {
        if (!socket) return;

        socket.on('youtube_sync', (state: any) => {
            if (state.url) setVideoUrl(state.url);
            if (state.isPlaying !== undefined) setIsPlaying(state.isPlaying);
        });

        return () => {
            socket.off('youtube_sync');
        };
    }, [socket]);

    const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newUrl = e.target.value;
        setVideoUrl(newUrl);
        socket?.emit('youtube_update', { url: newUrl });
    };

    const togglePlay = () => {
        const newState = !isPlaying;
        setIsPlaying(newState);
        socket?.emit('youtube_update', { isPlaying: newState });
    };

    const getEmbedUrl = (url: string) => {
        let embedId = "dQw4w9WgXcQ"; // Default
        try {
            const urlObj = new URL(url);
            if (urlObj.hostname.includes('youtube.com')) {
                embedId = urlObj.searchParams.get('v') || embedId;
            } else if (urlObj.hostname.includes('youtu.be')) {
                embedId = urlObj.pathname.slice(1) || embedId;
            }
        } catch (e) {}

        // We use autoplay=1 if isPlaying is true.
        // Note: Real iframe sync is hard without YouTube IFrame API, this is a parody approximation.
        return `https://www.youtube.com/embed/${embedId}?autoplay=${isPlaying ? 1 : 0}&mute=0`; 
    };

    return (
        <div className="flex flex-col h-full bg-black">
            <div className="flex-none p-4 bg-[#2b2d31] flex gap-2 border-b border-[#1e1f22]">
                <div className="bg-red-600 text-white px-3 py-1 rounded font-bold flex items-center gap-2">
                    <i className="fa-brands fa-youtube"></i> YouTube Together
                </div>
                <input 
                    type="text" 
                    value={videoUrl}
                    onChange={handleUrlChange}
                    className="flex-1 bg-[#1e1f22] text-gray-200 px-3 py-1 rounded border-none focus:ring-2 focus:ring-red-500 outline-none"
                    placeholder="Paste YouTube Link..."
                />
                <button 
                    onClick={togglePlay}
                    className={`${isPlaying ? 'bg-red-500' : 'bg-green-600'} text-white px-4 py-1 rounded transition-colors font-bold w-24`}
                >
                    {isPlaying ? 'PAUSE' : 'PLAY'}
                </button>
            </div>
            
            <div className="flex-1 flex items-center justify-center bg-black relative overflow-hidden">
                {/* Parody Overlay */}
                <div className="absolute top-4 left-4 bg-black/70 p-2 rounded text-white text-xs z-10 pointer-events-none">
                    Sync Status: {isPlaying ? 'PLAYING' : 'PAUSED'} (Parody Sync ™)
                </div>

                {/* We key the iframe to force reload when play state changes for this simple implementation */}
                <iframe 
                    key={`${videoUrl}-${isPlaying}`}
                    width="80%" 
                    height="80%" 
                    src={getEmbedUrl(videoUrl)} 
                    title="YouTube video player" 
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
                    referrerPolicy="strict-origin-when-cross-origin" 
                    allowFullScreen
                    className="shadow-2xl border border-gray-800"
                ></iframe>

                <div className="absolute bottom-10 right-10 flex flex-col items-end gap-2">
                     <span className="text-gray-400 text-xs bg-black/50 px-2 rounded">
                        Changes sync to all users
                     </span>
                </div>
            </div>
        </div>
    );
};

export default YouTubeTogether;