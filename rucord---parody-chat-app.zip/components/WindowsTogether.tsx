import React, { useState, useEffect } from 'react';

interface WindowsTogetherProps {
    socket: any;
}

const WindowsTogether: React.FC<WindowsTogetherProps> = ({ socket }) => {
  const [bsod, setBsod] = useState(false);
  const [icons, setIcons] = useState([
    { id: 1, name: 'My Computer', x: 20, y: 20, icon: 'fa-desktop' },
    { id: 2, name: 'Trash Bin', x: 20, y: 120, icon: 'fa-trash-can' },
    { id: 3, name: 'Secret_Plans.txt', x: 120, y: 20, icon: 'fa-file-lines' },
    { id: 4, name: 'Internet Explorer', x: 120, y: 120, icon: 'fa-globe' },
  ]);

  useEffect(() => {
    if(!socket) return;
    
    socket.on('windows_bsod_trigger', () => {
        setBsod(true);
        setTimeout(() => setBsod(false), 4000);
    });

    return () => {
        socket.off('windows_bsod_trigger');
    }
  }, [socket]);

  const crashSystem = () => {
    // Trigger locally and remotely
    setBsod(true);
    socket?.emit('windows_bsod');
    setTimeout(() => {
        setBsod(false); // Reboot
    }, 4000);
  };

  if (bsod) {
    return (
      <div className="w-full h-full bg-blue-800 text-white font-mono p-10 flex flex-col justify-center items-center select-none z-50 absolute inset-0">
        <h1 className="text-4xl mb-4 bg-white text-blue-800 px-2">Windows</h1>
        <p className="mb-4">A fatal exception 0E has occurred at 0028:C0011E36 in VXD VMM(01) + 00010E36. The current application will be terminated.</p>
        <p>* Press any key to terminate the current application.</p>
        <p>* Press CTRL+ALT+DEL again to restart your computer. You will lose any unsaved information in all applications.</p>
        <p className="mt-8 animate-pulse text-center">Press any key to continue _</p>
      </div>
    );
  }

  return (
    <div className="w-full h-full relative bg-[#008080] overflow-hidden border-4 border-gray-400 inset-0 shadow-2xl">
      {/* Taskbar */}
      <div className="absolute bottom-0 left-0 right-0 h-10 bg-[#c0c0c0] border-t-2 border-white flex items-center px-1 z-10">
        <button 
            onClick={crashSystem}
            className="flex items-center gap-2 px-4 py-1 bg-[#c0c0c0] border-t-2 border-l-2 border-white border-b-2 border-r-2 border-black active:border-t-black active:border-l-black active:border-r-white active:border-b-white font-bold text-black"
        >
            <i className="fa-brands fa-windows"></i> Start
        </button>
        <div className="ml-2 w-[2px] h-6 border-l border-gray-500 border-r border-white"></div>
        <div className="ml-auto bg-gray-200 border border-gray-500 px-2 py-1 text-xs text-black shadow-inner font-mono">
            {new Date().toLocaleTimeString()}
        </div>
      </div>

      {/* Desktop Icons */}
      {icons.map((icon) => (
        <div 
            key={icon.id}
            className="absolute flex flex-col items-center w-24 p-2 cursor-pointer hover:bg-blue-600/50 text-white group"
            style={{ top: icon.y, left: icon.x }}
            onClick={() => icon.name === 'Internet Explorer' ? crashSystem() : null}
        >
            <i className={`fa-solid ${icon.icon} text-4xl mb-1 drop-shadow-md`}></i>
            <span className="text-xs text-center drop-shadow-md bg-[#008080] group-hover:bg-blue-600 px-1">{icon.name}</span>
        </div>
      ))}

      {/* Active Window */}
      <div className="absolute top-1/4 left-1/4 w-96 bg-[#c0c0c0] border-2 border-white border-b-black border-r-black shadow-xl">
        <div className="bg-gradient-to-r from-blue-900 to-blue-700 text-white px-2 py-1 text-sm font-bold flex justify-between items-center">
            <span>Critical Error</span>
            <button className="bg-[#c0c0c0] text-black w-4 h-4 text-[10px] flex items-center justify-center border border-white border-b-black border-r-black">X</button>
        </div>
        <div className="p-4 flex gap-4 items-center">
            <i className="fa-solid fa-circle-xmark text-red-600 text-3xl"></i>
            <p className="text-black text-sm">Task failed successfully.</p>
        </div>
        <div className="p-2 flex justify-center">
            <button onClick={crashSystem} className="px-6 py-1 border-2 border-white border-b-black border-r-black active:border-t-black active:border-l-black bg-[#c0c0c0] text-black text-sm">OK</button>
        </div>
      </div>
    </div>
  );
};

export default WindowsTogether;