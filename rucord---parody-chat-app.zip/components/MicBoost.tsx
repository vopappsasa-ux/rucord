import React, { useEffect, useRef, useState } from 'react';

interface MicBoostProps {
  gainValue: number;
  setGainValue: (val: number) => void;
}

const MicBoost: React.FC<MicBoostProps> = ({ gainValue, setGainValue }) => {
  const [isListening, setIsListening] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const requestRef = useRef<number | null>(null);

  const toggleMic = async () => {
    if (isListening) {
      // Stop
      if (audioContextRef.current) {
        audioContextRef.current.close();
        audioContextRef.current = null;
      }
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
      }
      setIsListening(false);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      const ctx = audioContextRef.current;

      analyserRef.current = ctx.createAnalyser();
      analyserRef.current.fftSize = 256;
      
      gainNodeRef.current = ctx.createGain();
      gainNodeRef.current.gain.value = gainValue;

      sourceRef.current = ctx.createMediaStreamSource(stream);
      
      // Connect: Source -> Gain -> Analyser -> (Destination if we want self-hear, but risky for feedback)
      // We won't connect to destination to prevent feedback loops, just visualization.
      sourceRef.current.connect(gainNodeRef.current);
      gainNodeRef.current.connect(analyserRef.current);

      setIsListening(true);
      draw();
    } catch (err) {
      console.error("Mic Error", err);
      alert("Microphone access denied or error.");
    }
  };

  // Update gain in real-time
  useEffect(() => {
    if (gainNodeRef.current) {
      gainNodeRef.current.gain.value = gainValue;
    }
  }, [gainValue]);

  const draw = () => {
    if (!analyserRef.current || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const bufferLength = analyserRef.current.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    analyserRef.current.getByteFrequencyData(dataArray);

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const barWidth = (canvas.width / bufferLength) * 2.5;
    let barHeight;
    let x = 0;

    for (let i = 0; i < bufferLength; i++) {
      barHeight = dataArray[i];

      // Dynamic color based on intensity (distortion simulation)
      if (gainValue > 5 && barHeight > 200) {
        ctx.fillStyle = `rgb(${barHeight + 50}, 0, 0)`; // Red clipping
      } else if (gainValue > 2) {
         ctx.fillStyle = `rgb(${barHeight}, ${barHeight}, 0)`; // Yellow warning
      } else {
        ctx.fillStyle = 'rgb(88, 101, 242)'; // Discord Blurple
      }

      // Height influenced by gain visually
      const visualHeight = Math.min((barHeight / 2) * (1 + gainValue / 10), canvas.height);

      ctx.fillRect(x, canvas.height - visualHeight, barWidth, visualHeight);
      x += barWidth + 1;
    }

    requestRef.current = requestAnimationFrame(draw);
  };

  return (
    <div className="p-4 bg-gray-900 rounded-lg border border-gray-700 mt-2">
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-xs font-bold uppercase text-gray-400">Mic Input Sensitivity (PARODY)</h3>
        <span className={`text-xs font-bold ${gainValue > 10 ? 'text-red-500 animate-pulse' : 'text-green-500'}`}>
          {Math.round(gainValue * 100)}%
        </span>
      </div>
      
      <div className="flex gap-2 items-center mb-4">
         <button 
           onClick={toggleMic}
           className={`px-3 py-1 rounded text-sm font-bold transition-colors ${isListening ? 'bg-red-500 hover:bg-red-600' : 'bg-green-600 hover:bg-green-700'}`}
         >
           {isListening ? 'Disconnect Mic' : 'Test Mic'}
         </button>
         <div className="flex-1">
            <input 
              type="range" 
              min="1" 
              max="15" 
              step="0.1" 
              value={gainValue}
              onChange={(e) => setGainValue(parseFloat(e.target.value))}
              className="w-full accent-indigo-500"
            />
         </div>
      </div>

      <canvas 
        ref={canvasRef} 
        width={300} 
        height={60} 
        className="w-full h-16 bg-black rounded shadow-inner"
      />
      {gainValue > 10 && (
         <p className="text-[10px] text-red-400 mt-1 italic">
           WARNING: AUDIO CLIPPING IMMINENT. YOUR FRIENDS WILL HATE YOU.
         </p>
      )}
    </div>
  );
};

export default MicBoost;