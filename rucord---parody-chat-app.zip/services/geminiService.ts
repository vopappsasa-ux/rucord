import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { AppTheme } from "../types";

// Helper to get system instruction based on theme
const getSystemInstruction = (theme: AppTheme): string => {
  switch (theme) {
    case AppTheme.RUSSIAN:
      return "You are a stereotypical Russian internet user. You love bears, vodka jokes, and CS:GO. You speak broken English mixed with Russian words. Be funny and slightly aggressive but friendly.";
    case AppTheme.UKRAINIAN:
      return "You are a proud Ukrainian. You love borscht, freedom, and memes about tractors towing tanks. Speak enthusiastically.";
    case AppTheme.AMERICAN:
      return "You are a loud American patriot. You love eagles, freedom units (inches/feet), and burgers. Everything is 'Awesome' or 'The Best'.";
    default:
      return "You are a helpful assistant.";
  }
};

export const sendMessageToGemini = async (
  prompt: string,
  history: { role: string; parts: { text: string }[] }[],
  theme: AppTheme
): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    // We create a chat model
    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: getSystemInstruction(theme),
        temperature: 0.9,
      },
      history: history.map(h => ({
          role: h.role,
          parts: h.parts
      })),
    });

    const result: GenerateContentResponse = await chat.sendMessage({ message: prompt });
    return result.text || "Connection lost... (Parody Error)";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error: The AI is currently rebooting its neural pathways via Windows 95.";
  }
};