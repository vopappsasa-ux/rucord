export enum AppTheme {
  AMERICAN = 'AMERICAN',
  RUSSIAN = 'RUSSIAN',
  UKRAINIAN = 'UKRAINIAN',
}

export enum ViewState {
  LOGIN = 'LOGIN',
  APP = 'APP',
}

export enum ChannelType {
  TEXT = 'TEXT',
  VOICE = 'VOICE',
  AI = 'AI',
  WINDOWS = 'WINDOWS',
  YOUTUBE = 'YOUTUBE',
  GUIDE = 'GUIDE'
}

export interface Message {
  id: string;
  user: string;
  avatar: string;
  content: string;
  timestamp: string;
  role?: 'user' | 'model' | 'system';
}

export interface UserProfile {
  username: string;
  discriminator: string;
  avatar: string;
  micGain: number; // 1.0 to 15.0 (1500%)
  theme: AppTheme;
}
