const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// Serve static files if built (optional for dev, useful for prod)
app.use(express.static(path.join(__dirname, 'dist')));

// State
let users = {};
let youtubeState = {
  url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
  isPlaying: false,
  timestamp: 0
};

io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  // User Join
  socket.on('join', (userData) => {
    users[socket.id] = {
      id: socket.id,
      ...userData,
      isTyping: false
    };
    // Broadcast user list
    io.emit('user_list', Object.values(users));
    
    // Send current state to new user
    socket.emit('youtube_sync', youtubeState);
  });

  // Chat Message
  socket.on('message', (msg) => {
    io.emit('message', msg);
  });

  // Typing Status
  socket.on('typing', (isTyping) => {
    if (users[socket.id]) {
      users[socket.id].isTyping = isTyping;
      io.emit('user_list', Object.values(users));
    }
  });

  // Mic Gain Update
  socket.on('mic_gain', (gain) => {
    if (users[socket.id]) {
      users[socket.id].micGain = gain;
      io.emit('user_list', Object.values(users));
    }
  });

  // YouTube Together Sync
  socket.on('youtube_update', (newState) => {
    youtubeState = { ...youtubeState, ...newState };
    // Broadcast to everyone EXCEPT sender (to prevent loops)
    socket.broadcast.emit('youtube_sync', youtubeState);
  });

  // Windows Together BSOD Sync
  socket.on('windows_bsod', () => {
    io.emit('windows_bsod_trigger');
  });

  // Disconnect
  socket.on('disconnect', () => {
    delete users[socket.id];
    io.emit('user_list', Object.values(users));
    console.log('User disconnected:', socket.id);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});